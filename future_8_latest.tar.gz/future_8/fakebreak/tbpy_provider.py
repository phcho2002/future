"""tbpy 实时行情数据适配层 —— future_8 标准格式。

把 TBQuant 的 tbpy 接口封装成 generate_signal() 能直接吃的 DataFrame：
    升序排列 | 列: datetime, open, high, low, close, volume

关键事实（已通过连通性测试确认，2026-07）：
- 初始化：tbpy.init(key='tbquant3')，要求 tbquant3.exe 客户端在后台运行并登录
- 周期：frequency 用字符串 '15m' / '60m' / '1d'（不是 Min60 枚举）
- 主力连续合约代码：品种000.交易所，如 'IM000.CFFEX' 'PP000.DCE'
- get_history_n 返回 dict（不是 DataFrame），keys：
    open/high/low/close/volume/position/rollover/time，值为 numpy array
- time 是 datetime.datetime 对象，数组按时间升序（最旧在前）
- 限频：查询间隔需 ≥60s，单次最多约 20 个合约 → 调用方逐品种查 + sleep
"""
from __future__ import annotations

import time
from functools import lru_cache

import numpy as np
import pandas as pd

# future_8 品种代码 → TBQuant 主力连续 symbol 的映射。
#
# TBQuant 主力连续代码规则（实测确认，2026-07）：
#   - 商品期货：品种小写 + '000' + .交易所大写，如 'pp000.DCE' 'sc000.INE'
#   - 金融期货：品种大写 + '000' + .CFFEX，如 'IM000.CFFEX' 'IF000.CFFEX'
# 交易所代码统一大写。future_8 的 futures_top40.json 用大写品种(如 PP0)，
# 需在此表标注交易所 + 品种大小写。
# 格式: 品种大写 -> (交易所, 品种在TBQuant的大小写)
_SYMBOL_MAP = {
    # 大商所 DCE（商品，小写）
    "PP": ("DCE", "pp"), "JM": ("DCE", "jm"), "J": ("DCE", "j"), "M": ("DCE", "m"),
    "A": ("DCE", "a"), "C": ("DCE", "c"), "L": ("DCE", "l"), "P": ("DCE", "p"),
    "V": ("DCE", "v"), "I": ("DCE", "i"), "Y": ("DCE", "y"), "FB": ("DCE", "fb"),
    "BB": ("DCE", "bb"), "JD": ("DCE", "jd"), "LH": ("DCE", "lh"), "EG": ("DCE", "eg"),
    "EB": ("DCE", "eb"), "PG": ("DCE", "pg"), "RR": ("DCE", "rr"), "B": ("DCE", "b"),
    # 上期所 SHFE（商品，小写）
    "RB": ("SHFE", "rb"), "HC": ("SHFE", "hc"), "SS": ("SHFE", "ss"), "CU": ("SHFE", "cu"),
    "AL": ("SHFE", "al"), "ZN": ("SHFE", "zn"), "PB": ("SHFE", "pb"), "NI": ("SHFE", "ni"),
    "SN": ("SHFE", "sn"), "AU": ("SHFE", "au"), "AG": ("SHFE", "ag"), "FU": ("SHFE", "fu"),
    "RU": ("SHFE", "ru"), "BU": ("SHFE", "bu"), "BC": ("SHFE", "bc"), "SP": ("SHFE", "sp"),
    "AO": ("SHFE", "ao"), "BR": ("SHFE", "br"),
    # 能源中心 INE（商品，小写）
    "SC": ("INE", "sc"), "LU": ("INE", "lu"), "NR": ("INE", "nr"),
    # 中金所 CFFEX（金融，大写）
    "IF": ("CFFEX", "IF"), "IH": ("CFFEX", "IH"), "IC": ("CFFEX", "IC"),
    "IM": ("CFFEX", "IM"), "T": ("CFFEX", "T"), "TF": ("CFFEX", "TF"),
    "TS": ("CFFEX", "TS"), "TL": ("CFFEX", "TL"),
    # 广期所 GFEX（商品，小写）
    "LC": ("GFEX", "lc"), "SI": ("GFEX", "si"),
    # 郑商所 CZCE（商品，小写；注意 CZCE 三位合约如 MA509，但主力连续仍用 000）
    "MA": ("CZCE", "MA"), "TA": ("CZCE", "TA"), "SR": ("CZCE", "SR"), "CF": ("CZCE", "CF"),
    "CY": ("CZCE", "CY"), "AP": ("CZCE", "AP"), "CJ": ("CZCE", "CJ"), "RI": ("CZCE", "RI"),
    "WH": ("CZCE", "WH"), "PM": ("CZCE", "PM"), "FG": ("CZCE", "FG"), "OI": ("CZCE", "OI"),
    "RM": ("CZCE", "RM"), "RS": ("CZCE", "RS"), "SF": ("CZCE", "SF"), "SM": ("CZCE", "SM"),
    "SA": ("CZCE", "SA"), "UR": ("CZCE", "UR"), "PF": ("CZCE", "PF"), "SH": ("CZCE", "SH"),
    "PK": ("CZCE", "PK"), "PX": ("CZCE", "PX"),
}


def to_tbquant_symbol(future8_symbol: str) -> str | None:
    """future_8 品种代码 → TBQuant 主力连续 symbol。

    输入形如 'PP0' 'IM0'（带或不带尾部 0）；
    输出按交易所大小写规则：商品 'pp000.DCE'，金融 'IM000.CFFEX'。
    无法识别返回 None。
    """
    s = future8_symbol.strip().upper().rstrip("0123456789")
    entry = _SYMBOL_MAP.get(s)
    if entry is None:
        return None
    exchange, tbquant_code = entry
    return f"{tbquant_code}000.{exchange}"


@lru_cache(maxsize=1)
def _ensure_init() -> bool:
    """幂等初始化 tbpy（要求 tbquant3.exe 已启动并登录）。成功返回 True。"""
    import tbpy  # 延迟导入，扫描脚本在无 tbpy 环境也能加载本模块做静态检查

    if tbpy.is_init():
        return True
    ok = tbpy.init(key="tbquant3")
    return bool(ok)


def get_kline(
    future8_symbol: str,
    freq: str = "60m",
    count: int = 300,
) -> pd.DataFrame:
    """拉取某品种主力连续 K 线，返回 future_8 标准 DataFrame。

    Parameters
    ----------
    future8_symbol : str
        future_8 品种代码，如 'IM0' 'PP0'。
    freq : str
        TBQuant 周期字符串：'15m' / '60m' / '1d' 等。
    count : int
        要拉的根数。

    Returns
    -------
    DataFrame[datetime, open, high, low, close, volume]，升序（最旧在前）。
        失败返回空 DataFrame（列已就位，便于下游统一处理）。
    """
    import tbpy

    empty = pd.DataFrame(columns=["datetime", "open", "high", "low", "close", "volume"])
    if not _ensure_init():
        print(f"  [tbpy] init 失败：请确认 tbquant3.exe 已启动并登录")
        return empty

    symbol = to_tbquant_symbol(future8_symbol)
    if symbol is None:
        print(f"  [tbpy] {future8_symbol} 无法映射到 TBQuant 合约，跳过")
        return empty

    try:
        r = tbpy.get_history_n(symbol, freq, count)
    except Exception as e:  # noqa: BLE001
        print(f"  [tbpy] {symbol} 查询异常: {str(e)[:60]}")
        return empty

    if not isinstance(r, dict) or "time" not in r:
        print(f"  [tbpy] {symbol} 返回类型异常: {type(r)}")
        return empty

    return _dict_to_df(r)


def _dict_to_df(r: dict) -> pd.DataFrame:
    """单品种 OHLCV dict（tbpy 返回）→ future_8 标准 DataFrame。

    输入 keys 含 open/high/low/close/volume/time（值为 numpy array）。
    空数据返回空 DataFrame（列已就位）。
    """
    empty = pd.DataFrame(columns=["datetime", "open", "high", "low", "close", "volume"])
    n = len(r.get("time", []))
    if n == 0:
        return empty
    df = pd.DataFrame({
        "datetime": r["time"],
        "open": r["open"].astype(float),
        "high": r["high"].astype(float),
        "low": r["low"].astype(float),
        "close": r["close"].astype(float),
        "volume": r["volume"].astype(float),
    })
    # 去重（同一时间戳可能重复）、升序
    df = df.drop_duplicates(subset=["datetime"]).sort_values("datetime").reset_index(drop=True)
    # 去 OHLC 任一为 NaN 的行
    df = df.dropna(subset=["open", "high", "low", "close"]).reset_index(drop=True)
    return df


def get_klines_batch(
    future8_symbols: list[str],
    freq: str = "60m",
    count: int = 300,
) -> dict[str, pd.DataFrame]:
    """一次性批量拉取多个品种（推荐）。

    用 tbpy 的 symbol 列表查询，一次 get_history_n 拿全部品种 —— 算 1 次限频查询，
    比 fetch_many 逐个查快得多（6 品种 ~5min → ~10s）。

    返回 {future8_symbol: DataFrame}（key 是输入的 future_8 代码如 'PP0'）。
    映射失败或无数据的品种不包含在结果中。
    """
    import tbpy

    out: dict[str, pd.DataFrame] = {}
    if not future8_symbols:
        return out
    if not _ensure_init():
        print(f"  [tbpy] init 失败：请确认 tbquant3.exe 已启动并登录")
        return out

    # future_8 代码 → TBQuant symbol，跳过无法映射的
    sym_map: dict[str, str] = {}
    for f8 in future8_symbols:
        tbs = to_tbquant_symbol(f8)
        if tbs is None:
            print(f"  [tbpy] {f8} 无法映射到 TBQuant 合约，跳过")
        else:
            sym_map[tbs] = f8

    if not sym_map:
        return out

    tb_symbols = list(sym_map.keys())
    try:
        r = tbpy.get_history_n(tb_symbols, freq, count)
    except Exception as e:  # noqa: BLE001
        print(f"  [tbpy] 批量查询异常: {str(e)[:60]}")
        return out

    # 批量返回是 {tb_symbol: {open,high,...,time}}；单品种则是扁平 dict。
    if isinstance(r, dict) and r and "time" in next(iter(r.values())):
        for tb_sym, d in r.items():
            f8 = sym_map.get(tb_sym)
            if f8 is None:
                continue
            df = _dict_to_df(d)
            if not df.empty:
                out[f8] = df
            else:
                print(f"  [tbpy] {f8} ({tb_sym}) 无数据")
    else:
        print(f"  [tbpy] 批量返回结构异常: {type(r)}")
    return out


def fetch_many(
    symbols: list[str],
    freq: str = "60m",
    count: int = 300,
    interval_sec: float = 2.0,
) -> dict[str, pd.DataFrame]:
    """逐个拉取多个品种（fallback，逐品种查 + 限频间隔）。

    大多数场景应优先用 get_klines_batch（一次查完）。本函数仅在批量查询
    出问题时作降级。返回 {symbol: DataFrame}。
    """
    out: dict[str, pd.DataFrame] = {}
    for i, sym in enumerate(symbols):
        df = get_kline(sym, freq=freq, count=count)
        if not df.empty:
            out[sym] = df
        # 限频规避：相邻查询间隔
        if i < len(symbols) - 1 and interval_sec > 0:
            time.sleep(interval_sec)
    return out
